export function NotFound(){
    return <h2>404 Not Found</h2>
}