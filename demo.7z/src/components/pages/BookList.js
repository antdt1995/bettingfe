import { Link } from "react-router-dom";

export function BookList() {
  return (
    <>
      <h1>Booklist</h1>

    </>
  );
}
