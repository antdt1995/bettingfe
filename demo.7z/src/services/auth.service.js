import axios from "axios";

const API_URL = "http://localhost:8099/api/auth/";

class AuthService {
  register(firstName, lastName, username, password) {
    return axios.post(API_URL + "usersignup", {
      firstName,
      lastName,
      username,
      password,
    });
  }

  login(username, password) {
    return axios
      .post(API_URL + "signin", {
        username,
        password,
      })
      .then((response) => {
        if (response.data.jwttoken) {
          localStorage.setItem("user", JSON.stringify(response.data));
        }

        return response.data;
      });
  }

  logout() {
    localStorage.removeItem("user");
  }

  getCurrentUser() {
    return JSON.parse(localStorage.getItem("user"));
  }
}

export default new AuthService();