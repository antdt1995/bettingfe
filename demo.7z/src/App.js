import "./App.css";
import { Link, Route, Routes } from "react-router-dom";
import { Home } from "./components/pages/Home";
import { BookList } from "./components/pages/BookList";
import { Book } from "./components/pages/Book";
import { NewBook } from "./components/pages/NewBook";
import { NotFound } from "./components/pages/NotFound";
import { BookLayout } from "./BookLayout";
import { BookRoute } from "./BookRoute";
import { Foodaholic } from "./components/pages/Foodaholics"
import Login from "./components/login";
import Signup from "./components/register";

function App() {
  return (
    <>
 
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/login">Login</Link>
          </li>
          <li>
            <Link to="/Signup">Signup</Link>
          </li>
          <li>
            <Link to="/books">Book</Link>
          </li>
          <li>
            <Link to="/foodaholic">Foodaholic</Link>
          </li>
        </ul>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/books/*" element={<BookList />}/>
        <Route path="/foodaholic" element={<Foodaholic />}/>
        <Route path="/login" element={<Login />}/>
        <Route path="/signup" element={<Signup />}/>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

export default App;
